#include <xc.h>
#include "common.h"

/* store_event_in_ext_eeprom() defintion
 * Description : receives time,event and speed and stores it in external eeprom by calling 
   write_external_eeprom() ,only 10 events can be stored in eeprom if extra events occurs then 
   overwriting of previous events by recently occured events 
 */


void store_event_in_ext_eeprom(char *received_time,int received_event_ind,int received_speed)
{
        
    no_of_events++;
    
    if(no_of_events > 10)
    {
        
        /* overwriting logic to shift 1st to 9th position event to 0th to 8th position */
        for(short int i=0; i<9; i++)
        {
            for(short int j=0; j<12; j++)
            {
                write_external_eeprom(j+(i*12),read_external_eeprom(j+(i+1)*12));                
            }
        }
        store_address = 108; //address of 9th event 0th position
        
        /* to store new event at 9th position */
        //to store received time
        for(short int i=0; i<8; i++)
        {
            write_external_eeprom(store_address,received_time[i]);
            store_address++;            
        }       
        //to store event occured
        write_external_eeprom(store_address,event[received_event_ind][0]);
        store_address++;
        write_external_eeprom(store_address,event[received_event_ind][1]);
        store_address++;
        
        //to store received speed 
        write_external_eeprom(store_address,(received_speed / 10) + 48);
        store_address++;
        write_external_eeprom(store_address,(received_speed % 10) + 48); 
        no_of_events = 10;
        
    }
    else
    {
        /* storing events into external eeprom */
        
        //store the time received
        for(short int i=0; i<8; i++)
        {
            write_external_eeprom(store_address,received_time[i]);
            store_address++;            
        }       
        //to store event occured
        write_external_eeprom(store_address,event[received_event_ind][0]);
        store_address++;
        write_external_eeprom(store_address,event[received_event_ind][1]);
        store_address++;
        
        //to store received speed 
        write_external_eeprom(store_address,(received_speed / 10) + 48);
        store_address++;
        write_external_eeprom(store_address,(received_speed % 10) + 48);
        store_address++;        
    }   
}
