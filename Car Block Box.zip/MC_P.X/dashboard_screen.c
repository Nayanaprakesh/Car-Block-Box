#include <xc.h>
#include "common.h"

/* display_dashboard() definition
 * Description : displays time ,event signature and speed calculated 
   on dashboard screen and also stores the time ,event and speed in external eeprom
   whenever event is changed by calling store_event_in_ext_eeprom()
 */
void display_dashboard() {
    static int event_index = 0;
    static char collision_flag = 0;
    unsigned short adc_reg_val;

    static int sw2_delay = 0;
    static int sw3_delay = 0;
    static short int prev_event_index = 0;

    clcd_print("TIME    EVENT SP", LINE1(0));
    clcd_print(time, LINE2(0)); //to print time

    prev_event_index = event_index; //to store event index occured
    //to read speed from potentiometer 
    adc_reg_val = read_adc(CHANNEL4);
    //to check whether gears are GN, ON state or collision state
    if (event_index == 0 || event_index == 2 || event_index == 8) {
        clcd_print("00", LINE2(14));
    } else if (event_index == 1)//for GR speed 0-20
    {
        speed = ((float) adc_reg_val / 1023)*20;
    } else if (event_index == 3) // for G1 speed 0-30
    {
        speed = ((float) adc_reg_val / 1023)*30;
    } else if (event_index == 4) //for G2 speed 30-40
    {
        speed = 30 + (((float) adc_reg_val / 1023)*(40 - 30));
    } else if (event_index == 5) //for G3 speed 40-60
    {
        speed = 40 + (((float) adc_reg_val / 1023)*(60 - 40));
    } else if (event_index == 6) //for G4 speed 60-80
    {
        speed = 60 + (((float) adc_reg_val / 1023)*(80 - 60));
    } else if (event_index == 7) //for G5 speed 80-99
    {
        speed = 80 + (((float) adc_reg_val / 1023)*(100 - 80));
        if (speed >= 100)
            speed = 99;
    }

    clcd_putch((speed / 10) + 48, LINE2(14));
    clcd_putch((speed % 10) + 48, LINE2(15));

    //check whether sw2 is pressed 
    if (key == MK_SW2) {
        sw2_delay++;
    } else if (key == MK_SW3) {
        sw3_delay++;
    }

    if (sw2_delay > 0 && sw2_delay <= 100 && key == ALL_RELEASED) {
        //check whether collision occured
        if (collision_flag) {
            event_index = 2; //to start from gear reverse we initialize with 0
            collision_flag = 0;
        } else
            event_index++; //increment the gear
        if (event_index > 7)
            event_index = 7;
        sw2_delay = 0;
        sw3_delay = 0;

    } else if (sw2_delay > 100) {
        sw2_delay = 0;
        sw3_delay = 0;
    }

    if (sw3_delay > 0 && sw3_delay <= 100 && key == ALL_RELEASED) {
        if (collision_flag) {
            event_index = 2; //to start from gear reverse we initialize with 2
            collision_flag = 0;
        } else
            event_index--; //decrement the gear
        if (event_index < 1)
            event_index = 1;

        sw3_delay = 0;
        sw2_delay = 0;
    } else if (sw3_delay > 100) {
        sw3_delay = 0;
        sw2_delay = 0;
    }
    if (key == MK_SW1)//check if collision occured i.e. sw1 is pressed
    {
        event_index = 8; //bcoz c_ is at 8th index in array
        collision_flag = 1;
    }
    //to print gear
    clcd_print(event[event_index], LINE2(10));
    clcd_print("  ", LINE2(13));

    //to store in external eeprom whenever event changes from prev
    if (prev_event_index != event_index) {
        store_event_in_ext_eeprom(time, event_index, speed);
    }


}
