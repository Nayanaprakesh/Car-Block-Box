#include <xc.h>
#include "common.h"
#include <string.h>

/* view_log() definition
 * Description : displays all the events stored in external eeprom
   Displays max no. of events stored in eeprom
 */


void view_log() {
    clcd_print("# _-VIEW_LOG-_  ", LINE1(0));

    //to calculate the delay of switch pressed
    if (key == MK_SW11) {
        sw11_delay++;
    } else if (key == MK_SW12) {
        sw12_delay++;
    }
    //if long press of sw6 occurs then enter into menu screen
    if (sw12_delay > 300) {
        sw12_delay = 0;
        sw11_delay = 0;
        MENU_FLAG = 0;
    }
    //if no events are stored
    if (no_of_events == 0)
        clcd_print("No recent events", LINE2(0));

    if (view_event < no_of_events) {

        if (sw11_delay > 2 && sw11_delay <= 150 && key == ALL_RELEASED) {//to check sw1 pressed or not

            view_event--;
            if (view_event < 0)
                view_event = no_of_events - 1;

            sw11_delay = 0;
            sw12_delay = 0;
        } else if (sw11_delay > 150) {
            sw11_delay = 0;
            sw12_delay = 0;
        }
        if (sw12_delay > 2 && sw12_delay <= 150 && key == ALL_RELEASED) {//to check sw2 pressed or not
            if (view_event != no_of_events)
                view_event++;
            if (view_event == no_of_events)
                view_event = 0;
            sw11_delay = 0;
            sw12_delay = 0;
        }
        store_address = view_event * 12;

        //to read time
        char read_time[9];
        for (int j = 0; j < 8; j++) {
            read_time[j] = read_external_eeprom(store_address);
            store_address++;
        }
        read_time[8] = '\0';
        clcd_putch(view_event + 48, LINE2(0));
        clcd_putch(' ', LINE2(1));
        clcd_print(read_time, LINE2(2));
        clcd_putch(' ', LINE2(10));
        //to read event
        clcd_putch(read_external_eeprom(store_address), LINE2(11));
        store_address++;
        clcd_putch(read_external_eeprom(store_address), LINE2(12));
        store_address++;
        clcd_putch(' ', LINE2(13));
        //to read speed
        clcd_putch(read_external_eeprom(store_address), LINE2(14));
        store_address++;
        clcd_putch(read_external_eeprom(store_address), LINE2(15));

    } else {
        view_event = 0;
    }
}

/* clear_log() definition
 * Description : clears all the events stored in external eeprom
 */


void clear_log() {
    clcd_print("Clear log       ", LINE1(0));
    clcd_print("Successfull     ", LINE2(0));
    //to calculate the delay of switch pressed
    if (key == MK_SW12) {
        sw12_delay++;
    }
    //if long press of sw6 occurs then enter into menu screen
    if (sw12_delay > 300) {
        sw12_delay = 0;
        MENU_FLAG = 0;
    }
}
/* download_log() definition
 * Description : downloads all the events stored in external eeprom and displays in teraterm screen
*/

static int download_once = 1;

void download_log() {

    clcd_print("Logs are        ", LINE1(0));
    clcd_print("Downloading     ", LINE2(0));
    //to display on teraterm
    puts("#   Time       Ev  Speed \n\r");
    
    for (view_event = 0; view_event < no_of_events; view_event++) {
        store_address = view_event * 12;

        //to read time
        char read_time[9];
        for (int j = 0; j < 8; j++) {
            read_time[j] = read_external_eeprom(store_address);
            store_address++;
        }
        read_time[9] = '\0';

        putch(view_event + 48);
        puts("  ");
        puts(read_time);
        puts("    ");

        //to read event
        putch(read_external_eeprom(store_address));
        store_address++;
        putch(read_external_eeprom(store_address));
        store_address++;
        puts("   ");

        //to read speed
        putch(read_external_eeprom(store_address));
        store_address++;
        putch(read_external_eeprom(store_address));
        store_address++;
        puts("\n\r");

    }
    //to enter into menu screen
    for (unsigned int k = 50000; k--;);
    MENU_FLAG = 0;
}

/* change_password() definition
 * Description : asks the user to enter new pwd and renenter the new pwd if both matches then 
 stores in external eeprom and password gets updated else password doesnt gets upadted
 */

static char new_pwd[5];
static char re_entered_pwd[5];
static char re_enter_flag = 0;
static char key_press1;
static char key_press2;

void change_password() {
    if (re_enter_flag == 0) {
        if (key_press1 < 4) {

            clcd_print("Enter new Pwd  ", LINE1(0));
            if (i == 0) {

                //to blink the cursor at first position before entering any character
                if (wait++ < 100) {
                    clcd_print(" _              ", LINE2(0));
                } else if (wait < 200) {
                    clcd_print("                ", LINE2(0));
                } else {
                    wait = 0;
                }
            } else {
                //to blink the cursor at particular position where password need to be entered
                if (wait2++ < 100) {
                    clcd_putch('_', LINE2(i + 1));
                } else if (wait2 < 200) {
                    clcd_putch(' ', LINE2(i + 1));
                } else {
                    wait2 = 0;
                }
            }

            //to calculate the delay of key 5 and 6 pressed
            if (key == MK_SW11) {
                sw11_delay++;
            } else if (key == MK_SW12) {
                sw12_delay++;
            }
            if (sw11_delay > 2 && sw11_delay <= 100 && key == ALL_RELEASED) {//to check sw1 pressed or not
                new_pwd[i] = 0 + 48; //store 0 to entered password array
                key_press1++;
                i++;
                clcd_putch('*', LINE2(i));
                sw11_delay = 0;
            } else if (sw11_delay > 100) {
                sw11_delay = 0;
                sw12_delay = 0;
            }
            if (sw12_delay > 2 && sw12_delay <= 100 && key == ALL_RELEASED) {//to check sw2 pressed or not
                new_pwd[i] = 1 + 48; //store 1 to entered password array
                key_press1++;
                i++;
                clcd_putch('*', LINE2(i));
                sw12_delay = 0;
            } else if (sw12_delay > 100) {
                sw12_delay = 0;
                sw11_delay = 0;
            }
        }
    }
    if (key_press1 >= 4 && re_enter_flag == 0) {
        re_enter_flag = 1;
        new_pwd[i] = '\0';
        wait = 0;
        CLEAR_DISP_SCREEN;
        i = 0;
    }

    if (re_enter_flag) {
        if (key_press2 < 4) {

            clcd_print("Re-enter new Pwd  ", LINE1(0));
            if (i == 0) {

                //to blink the cursor at first position before entering any character
                if (wait++ < 100) {
                    clcd_print(" _              ", LINE2(0));
                } else if (wait < 200) {
                    clcd_print("                ", LINE2(0));
                } else {
                    wait = 0;
                }
            } else {
                //to blink the cursor at particular position where password need to be entered
                if (wait2++ < 100) {
                    clcd_putch('_', LINE2(i + 1));
                } else if (wait2 < 200) {
                    clcd_putch(' ', LINE2(i + 1));
                } else {
                    wait2 = 0;
                }
            }

            //to calculate the delay of key 5 and 6 pressed
            if (key == MK_SW11) {
                sw11_delay++;
            } else if (key == MK_SW12) {
                sw12_delay++;
            }
            if (sw11_delay > 2 && sw11_delay <= 100 && key == ALL_RELEASED) {//to check sw1 pressed or not
                re_entered_pwd[i] = 0 + 48; //store 0 to entered password array
                key_press2++;
                i++;
                clcd_putch('*', LINE2(i));
                sw11_delay = 0;
            } else if (sw11_delay > 100) {
                sw11_delay = 0;
                sw12_delay = 0;
            }
            if (sw12_delay > 2 && sw12_delay <= 100 && key == ALL_RELEASED) {//to check sw2 pressed or not
                re_entered_pwd[i] = 1 + 48; //store 1 to entered password array
                key_press2++;
                i++;
                clcd_putch('*', LINE2(i));
                sw12_delay = 0;
            } else if (sw12_delay > 100) {
                sw12_delay = 0;
                sw11_delay = 0;
            }
        }

    }
    if (key_press2 >= 4) {
        re_entered_pwd[i] = '\0';
        //CLEAR_DISP_SCREEN; 
        //compares the new pwd and re entered pwd if matches pwd gets updated
        if (strcmp(new_pwd, re_entered_pwd) == 0) {
            clcd_print("Password Changed ", LINE1(0));
            clcd_print("Successfully     ", LINE2(0));
            write_external_eeprom(130, new_pwd[0]);
            write_external_eeprom(131, new_pwd[1]);
            write_external_eeprom(132, new_pwd[2]);
            write_external_eeprom(133, new_pwd[3]);

            if (wait++ == 350) {
                wait = 0;
                key_press1 = 0;
                key_press2 = 0;
                re_enter_flag = 0;
                i = 0;
                MENU_FLAG = 0;
            }

        } else {
            clcd_print("Password  not   ", LINE1(0));
            clcd_print("Changed         ", LINE2(0));
            if (wait++ == 800) {
                wait = 0;
                key_press1 = 0;
                key_press2 = 0;
                re_enter_flag = 0;
                i = 0;
                MENU_FLAG = 0;
            }
        }
    }
}

/* set_time() definition
 * Description : user can set the time using MKP5 short press to notify the field blinking of fields will be 
   present ,we can change the fields by short press of MKP6 and we can set the time by long press of MKP5 
 */

static char read_time_flag = 1;
unsigned char hour = 0;
unsigned char minute = 0;
unsigned char second = 0;
static short int change_field;
static int delay;
char change_time[16] = "00:00:00       ";


void set_time() {
    //if (time_flag)
    clcd_print("HH:MM:SS        ", LINE1(0));
    //clcd_print("                ", LINE2(0));
    if (read_time_flag) {
        change_time[0] = time[0];
        change_time[1] = time[1];
        change_time[3] = time[3];
        change_time[4] = time[4];
        change_time[6] = time[6];
        change_time[7] = time[7];
        read_time_flag = 0;
        clcd_print("                  ", LINE2(0));
    }
    if (key == MK_SW11) {
        sw11_delay++;
    } else if (key == MK_SW12) {
        sw12_delay++;
    }
    if (display_blinking) {
        //to blink sec field
        if (change_field == 0) {
            if (delay++ < 100) {
                clcd_print(change_time, LINE2(0));

            } else if (delay < 200) {
                clcd_print("  ", LINE2(6));
            } else
                delay = 0;
        } else if (change_field == 1) {//to blink min field
            if (delay++ < 100) {
                clcd_print(change_time, LINE2(0));
            } else if (delay < 200) {
                clcd_print("  ", LINE2(3));
            } else
                delay = 0;
        } else if (change_field == 2) {//to blink hour field
            if (delay++ < 100) {
                clcd_print(change_time, LINE2(0));
            } else if (delay < 200) {
                clcd_print("  ", LINE2(0));
            } else
                delay = 0;
        }
    }



    if (sw12_delay > 2 && sw12_delay <= 100 && key == ALL_RELEASED) {//to check sw2 pressed or not
        //to change the field
        change_field++;
        if (change_field > 2) {
            change_field = 0;
        }
        sw12_delay = 0;
    } else if (sw12_delay > 100) {
        //to not update the time 
        display_blinking = 0;
        clcd_print("Time not updated", LINE1(0));
        clcd_print("                ", LINE2(0));
        if (wait++ == 800) {
            wait = 0;
            sw12_delay = 0;
            sw11_delay = 0;
            MENU_FLAG = 0;
        }

    }

    if (sw11_delay > 2 && sw11_delay <= 200 && key == ALL_RELEASED) {
        //to inc the sec
        if (change_field == 0) {
            change_time[7]++;
            if (change_time[7] > '9') {
                change_time[7] = '0';
                change_time[6]++;
            }
            if (change_time[6] == '6') {
                change_time[6] = '0';
                change_time[7] = '0';

            }
        } else if (change_field == 1) {//to inc min
            change_time[4]++;
            if (change_time[4] > '9') {
                change_time[4] = '0';
                change_time[3]++;
                if (change_time[3] == '6') {
                    change_time[3] = '0';
                    change_time[4] = '0';

                }
            }

        } else if (change_field == 2) {//to inc hour
            change_time[1]++;
            if (change_time[1] == '4' && change_time[0] == '2') {
                change_time[0] = '0';
                change_time[1] = '0';
            }
            if (change_time[1] > '9') {
                change_time[1] = '0';
                change_time[0]++;
            }
        }
        sw11_delay = 0;
    } else if (sw11_delay > 200) {
        //to set the time
        display_blinking = 0;
        clcd_print("Time updated", LINE1(0));
        clcd_print("                ", LINE2(0));

        //to store time in RTC
        hour = (change_time[0] - '0') << 4;
        hour = (change_time[1] - '0') | hour;
        write_ds1307(HOUR_ADDR, hour);
        minute = (change_time[3] - '0') << 4;
        minute = (change_time[4] - '0') | minute;
        write_ds1307(MIN_ADDR, minute);
        second = (change_time[6] - '0') << 4;
        second = (change_time[7] - '0') | second;
        write_ds1307(SEC_ADDR, second);
        //to enter into menu screen after some delay
        if (wait++ == 800) {
            wait = 0;
            sw12_delay = 0;
            sw11_delay = 0;
            MENU_FLAG = 0;
        }
    }

}




