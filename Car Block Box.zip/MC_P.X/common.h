#ifndef COMMON_H
#define	COMMON_H

/* Screen Macros */

#define DASH_BOARD 0
#define PASSWORD_SCREEN 1
#define MENU_SCREEN 2

/* Menu Screen log Macros */

#define VIEW_LOG 3
#define DOWNLOAD_LOG 4
#define CLEAR_LOG 5
#define SET_TIME 6
#define CHANGE_PASSWORD 7

/* Common declaration */

unsigned int SCREEN_FLAG = DASH_BOARD ;
unsigned int MENU_FLAG ;
unsigned char key;
char *event[13] = {"ON", "GR", "GN", "G1", "G2", "G3", "G4", "G5", "C_","DL","CL","ST","CP"};
//char *menu_events[]={"DL","CL","ST","CP"};
char str[3]; //to store password
int speed;
static unsigned int sw11_delay = 0;
static unsigned int sw12_delay = 0;
int no_of_events;
int store_address = 0x00;
static int view_event = 0;
char display_blinking = 1;

unsigned char clock_reg[3];
unsigned char time[9];

//for clear log function
//short int clear_log_flag = 0;

//for password entering
static unsigned char key_press = 0; //no. of key press
static int wait = 0; // to give delay for first cursor blinking
static int wait2 = 0; // to give delay for cursor blinking
static char entered_pwd[5]; //to store the entered password from user
static unsigned char i = 0; //index to store the entered character into array 



void display_dashboard();
void password_screen();
void display_menu();
//static void get_time();
void store_event_in_ext_eeprom(char *received_time,int received_event_ind,int received_speed);
void view_log();
void clear_log();
void download_log();
void change_password();
void set_time(void);
void get_time(void);

/* adc declaration */

#define CHANNEL4		0x04

void init_adc(void);
unsigned short read_adc(unsigned char channel);

/* CLCD declarations */
#define CLCD_PORT			PORTD
#define CLCD_EN				RC2
#define CLCD_RS				RC1
#define CLCD_RW				RC0
#define CLCD_BUSY			RD7
#define PORT_DIR			TRISD7


#define HI												1
#define LO												0

#define INPUT											0xFF
#define OUTPUT											0x00

#define DATA_COMMAND									1
#define INSTRUCTION_COMMAND								0
#define _XTAL_FREQ                  20000000
#define LINE1(x)									(0x80 + (x))
#define LINE2(x)										(0xC0 + (x))

#define TWO_LINE_5x8_MATRIX_8_BIT					clcd_write(0x38, INSTRUCTION_COMMAND)
#define CLEAR_DISP_SCREEN				                clcd_write(0x01, INSTRUCTION_COMMAND)
#define CURSOR_HOME							clcd_write(0x02, INSTRUCTION_COMMAND)
#define DISP_ON_AND_CURSOR_OFF						clcd_write(0x0C, INSTRUCTION_COMMAND)
#define EIGHT_BIT_MODE   0x33
void init_clcd(void);
void clcd_print(const unsigned char *data, unsigned char addr);
void clcd_putch(const unsigned char data, unsigned char addr);
void clcd_write(unsigned char bit_values, unsigned char control_bit);


/*Matrix keypad declaration */

#define MAX_ROW				4
#define MAX_COL				3

#define STATE_CHANGE				1
#define LEVEL_CHANGE				0
#define MATRIX_KEYPAD_PORT			PORTB
#define ROW3					PORTBbits.RB7
#define ROW2					PORTBbits.RB6
#define ROW1					PORTBbits.RB5
#define COL4					PORTBbits.RB4
#define COL3					PORTBbits.RB3
#define COL2					PORTBbits.RB2
#define COL1					PORTBbits.RB1


#define MK_SW1					1
#define MK_SW2					2
#define MK_SW3					3
#define MK_SW4					4
#define MK_SW5					5
#define MK_SW6					6
#define MK_SW7					7
#define MK_SW8					8
#define MK_SW9					9
#define MK_SW10				10
#define MK_SW11				11
#define MK_SW12				12

#define ALL_RELEASED	0xFF

#define HI				1
#define LO				0

void init_matrix_keypad(void);
unsigned char scan_key(void);
unsigned char read_switches(unsigned char detection_type);

//EEPROM declaration

void write_internal_eeprom(unsigned char address, unsigned char data); 
unsigned char read_internal_eeprom(unsigned char address);


//i2c declarations

void init_i2c(void);
void i2c_start(void);
void i2c_rep_start(void);
void i2c_stop(void);
void i2c_write(unsigned char data);
unsigned char i2c_read(void);

//external eeprom declarations

#define SLAVE_READ_		0xA1
#define SLAVE_WRITE_		0xA0


void write_external_eeprom(unsigned char address1,  unsigned char data);
unsigned char read_external_eeprom(unsigned char address1);

/* RTC ds1307 declaration */
#define SLAVE_READ		0xD1
#define SLAVE_WRITE		0xD0


#define SEC_ADDR		0x00
#define MIN_ADDR		0x01
#define HOUR_ADDR		0x02

#define CNTL_ADDR		0x07

void init_ds1307();
void write_ds1307(unsigned char address1,  unsigned char data);
unsigned char read_ds1307(unsigned char address1);


/* UART declarations */

#define RX_PIN					TRISC7
#define TX_PIN					TRISC6

void init_uart(void);
void putch(unsigned char byte);
int puts(const char *s);
unsigned char getch(void);
unsigned char getch_with_timeout(unsigned short max_time);
unsigned char getche(void);


#endif	/* COMMON_H */

