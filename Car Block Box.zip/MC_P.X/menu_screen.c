#include <xc.h>
#include "common.h"
#include <string.h>

char *menu[5] = {"VIEW_LOG       ", "DOWNLOAD_LOG   ", "CLEAR_LOG      ", "SET_TIME       ", "CHANGE_PASSWORD"};

/* display_menu() definition
 * Description : navigates the menu (view_log, download_log, clear_log, set_time, change_password)
   whenever the short press of MKP5 and 6 are pressed when long press of MKP5 is done on particular
   menu option it shouls enter into the particular option
 */

void display_menu() {
    static int menu_ind = 0;
    static int arrow_mark = 0;
    static int enter_menu;
    

    //check if MK5 is pressed    
    if (key == MK_SW11)
        sw11_delay++;
    else if (key == MK_SW12)//check if MK6 is pressed    
        sw12_delay++;

    //if downkey is pressed for 1st time then make print arrow mark down for same options
    if (sw12_delay > 1 && sw12_delay < 75 && key == ALL_RELEASED && arrow_mark == 0) {
        arrow_mark = 1;
        enter_menu++;
        sw12_delay = 0;
        sw11_delay = 0;
    } else if (sw12_delay > 1 && sw12_delay < 75 && key == ALL_RELEASED && arrow_mark == 1) {
        menu_ind++; //if arrrow_mark is at down inc menu to go for below options
        if (menu_ind > 3)
            menu_ind = 3;
        enter_menu++;
        if (enter_menu > 4)
            enter_menu = 4;
        sw12_delay = 0;
        sw11_delay = 0;
    } else if (sw12_delay >= 75) {
        sw12_delay = 0;
        sw11_delay = 0;
    }

    if (sw11_delay > 1 && sw11_delay < 75 && key == ALL_RELEASED && arrow_mark == 1) {
        arrow_mark = 0;
        enter_menu--;
        if (enter_menu < 0)
            enter_menu = 0;
        sw11_delay = 0;
        sw12_delay = 0;
    } else if (sw11_delay > 1 && sw11_delay < 75 && key == ALL_RELEASED && arrow_mark == 0) {
        menu_ind--; //if arrrow_mark is at up dec menu to go for above options
        if (menu_ind < 0)
            menu_ind = 0;
        enter_menu--;
        if (enter_menu < 0)
            enter_menu = 0;
        sw11_delay = 0;
        sw12_delay = 0;
    }
    //on long press of sw5 it should enter into particular option by changing the MENU_FLAG macro
    if (sw11_delay >= 260) {
        
        view_event = 0;
        sw11_delay = 0;
        sw12_delay = 0;
        
        clcd_print("                ", LINE2(0));
        if (enter_menu == 0){
            store_address = 0;
            CLEAR_DISP_SCREEN;
            MENU_FLAG = VIEW_LOG; //view log 
        }
        else if (enter_menu == 1) {
            store_event_in_ext_eeprom(time, 9, speed);
            wait=0;
            MENU_FLAG = DOWNLOAD_LOG; //download log
            CLEAR_DISP_SCREEN;

        } else if (enter_menu == 2) {
            store_address = 0;
            no_of_events = 0;
            store_event_in_ext_eeprom(time, 10, speed);
            MENU_FLAG = CLEAR_LOG; //clear log

        } else if (enter_menu == 3) {
            store_event_in_ext_eeprom(time, 11, speed);
            wait = 0;
            CLEAR_DISP_SCREEN;
            MENU_FLAG = SET_TIME; //set time

        } else if (enter_menu == 4) {
            store_event_in_ext_eeprom(time, 12, speed);
            MENU_FLAG = CHANGE_PASSWORD; //change password

        }
    }

    //to print arrow mark
    if (arrow_mark == 0)//if arrow is 0 then print arrow mark in 1st line
    {
        clcd_print("*", LINE1(0));
        clcd_print("  ", LINE2(0));
    } else//if arrow is 1 then print arrow mark in 2nd line
    {
        clcd_print("  ", LINE1(0));
        clcd_print("*", LINE2(0));
    }

    //to print menu options in screen
    clcd_print(menu[menu_ind], LINE1(2));
    clcd_print(menu[menu_ind + 1], LINE2(2));

}

