#include <xc.h>
#include "common.h"
#include <string.h>


static unsigned char attempt_flag = 3; //no of attempts

static int delay = 0; // delay to reinitialize all the required variables after attempt fail
static unsigned short wait_count = 60; //to display 60sec dec 


/* password_screen() definition
 * Description : asks for enter password from user and if entered password matches the stored password
   in eeprom then enters into menu screen else 3 attempts are given to enter correct pwd if all attempts
   fails blocks the user for 60sec
 */


void password_screen() {
    char original_pwd[5] = "0000"; // array to store original password
    static int flag = 1; //to decrement the no. of attempts
    static int no_key_pressed_delay = 0;
    char read_pwd[5]; // array to store original password read from EEPROM

    //to read password stored in eeprom
            read_pwd[0] = read_external_eeprom(130);
            read_pwd[1] = read_external_eeprom(131);
            read_pwd[2] = read_external_eeprom(132);
            read_pwd[3] = read_external_eeprom(133);
            read_pwd[4] = '\0';
    //to store the original password into eeprom
    if (strcmp(read_pwd, original_pwd) == 0) {
        write_external_eeprom(130, original_pwd[0]);
        write_external_eeprom(131, original_pwd[1]);
        write_external_eeprom(132, original_pwd[2]);
        write_external_eeprom(133, original_pwd[3]);
    }


    if (attempt_flag > 0) {
        if (key_press < 4) {
            wait_count = 60;
            clcd_print("Enter Password  ", LINE1(0));
            if (i == 0) {

                //to blink the cursor at first position before entering any character
                if (wait++ < 70) {
                    clcd_print(" _              ", LINE2(0));
                } else if (wait < 120) {
                    clcd_print("                ", LINE2(0));
                } else {
                    wait = 0;
                }
            } else {
                //to blink the cursor at particular position where password need to be entered
                if (wait2++ < 70) {
                    clcd_putch('_', LINE2(i + 1));
                } else if (wait2 < 120) {
                    clcd_putch(' ', LINE2(i + 1));
                } else {
                    wait2 = 0;
                }
            }

            //calculate the delay of key released after entering into password screen
            if (key != MK_SW11 && key != MK_SW12 && key == ALL_RELEASED)
                no_key_pressed_delay++;
            //if any key is not pressed for 5sec enter into dashboard
            if (no_key_pressed_delay >= 800) {
                clcd_print("                ", LINE2(0));
                i = 0;
                key_press = 0;
                attempt_flag = 3;
                SCREEN_FLAG = DASH_BOARD; //enter into dashboard
                no_key_pressed_delay = 0;
            }
            //to calculate the delay of key 5 and 6 pressed
            if (key == MK_SW11) {
                sw11_delay++;
            } else if (key == MK_SW12) {
                sw12_delay++;
            }
            if (sw11_delay > 2 && sw11_delay <= 100 && key == ALL_RELEASED) {//to check sw1 pressed or not
                entered_pwd[i] = 0 + 48; //store 0 to entered password array
                key_press++;
                i++;
                clcd_putch('*', LINE2(i));
                sw11_delay = 0;
            } else if (sw11_delay > 100) {
                sw11_delay = 0;
                sw12_delay = 0;
            }
            if (sw12_delay > 2 && sw12_delay <= 100 && key == ALL_RELEASED) {//to check sw2 pressed or not
                entered_pwd[i] = 1 + 48; //store 1 to entered password array
                key_press++;
                i++;
                clcd_putch('*', LINE2(i));
                sw12_delay = 0;
            } else if (sw12_delay > 100) {
                sw12_delay = 0;
                sw11_delay = 0;
            }
        } else {
            entered_pwd[i] = '\0'; //to end the array which has entered password
            
            //to compare the entered and original password read from eeprom
            if (strcmp(read_pwd, entered_pwd) == 0) {
                clcd_print("Password Matched", LINE1(0));
                clcd_print("Enter into Menu", LINE2(0));
                if (delay++ == 150) {
                    SCREEN_FLAG = MENU_SCREEN; //to enter into menu screen
                    delay = 0;
                    CLEAR_DISP_SCREEN;
                    sw11_delay = 0;
                    sw12_delay = 0;
                    clcd_print("                ", LINE1(0));
                    clcd_print("                ", LINE2(0));
                }
            } else {
                //to decrement the no. of attempts for each failed attempt
                if (flag) {
                    attempt_flag--; //decrement the attempts at each wrong password
                    flag = 0;
                    //delay = 0;
                }
                clcd_print("Wrong Password", LINE1(0));
                clcd_print("Attempt left", LINE2(0));
                clcd_putch(attempt_flag + 48, LINE2(13)); //to print the remaining attempts 
                // delay to reinitialize all the required variables after attempt fail
                if (delay++ == 150) {
                    i = 0;
                    key_press = 0;
                    delay = 0;
                    no_key_pressed_delay = 0;
                    flag = 1;
                    clcd_print("                ", LINE2(0)); // to clear the line2 of clcd
                }
            }
        }
    } else {
        //to block the user for 60 sec if all attempts get failed
        clcd_print(" User Blocked   ", LINE1(0));
        clcd_print("Wait..        ", LINE2(0));

        if (delay++ == 100) {
            clcd_putch((wait_count / 10) + 48, LINE2(14));
            clcd_putch((wait_count % 10) + 48, LINE2(15));
            wait_count--;
            if (wait_count == 0) {
                attempt_flag = 3;
                key_press = 0;
                i = 0;
                flag = 1;
                clcd_print("                ", LINE2(0));
            }
            delay = 0;

        }
    }
}