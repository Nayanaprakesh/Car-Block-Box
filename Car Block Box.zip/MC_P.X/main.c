#include <xc.h>
#include "common.h"

#pragma config WDT = OFF //Watchdog timer disabled

/* get time function definition
 * Description : get time() reads time from RTC (ds1307) 
   by calling read_ds1307() and stores in time array
 */
void get_time(void) {
    clock_reg[0] = read_ds1307(HOUR_ADDR);
    clock_reg[1] = read_ds1307(MIN_ADDR);
    clock_reg[2] = read_ds1307(SEC_ADDR);

    if (clock_reg[0] & 0x40) {
        time[0] = '0' + ((clock_reg[0] >> 4) & 0x01);
        time[1] = '0' + (clock_reg[0] & 0x0F);
    } else {
        time[0] = '0' + ((clock_reg[0] >> 4) & 0x03);
        time[1] = '0' + (clock_reg[0] & 0x0F);
    }
    time[2] = ':';
    time[3] = '0' + ((clock_reg[1] >> 4) & 0x0F);
    time[4] = '0' + (clock_reg[1] & 0x0F);
    time[5] = ':';
    time[6] = '0' + ((clock_reg[2] >> 4) & 0x0F);
    time[7] = '0' + (clock_reg[2] & 0x0F);
    time[8] = '\0';
}

/*init_uart() definition
  Description : initialization of uart 
*/

void init_uart(void) {
    /* Serial initialization */
    RX_PIN = 1;
    TX_PIN = 0;

    /* TXSTA:- Transmitor Status and control Register */
    /* 9bit TX enable or disable bit */
    TX9 = 0;
    /* UART Tarsmition enable bit */
    TXEN = 1;
    /* Synchronous or Asynchronous mode selection */
    /* Asynchronous */
    SYNC = 0;
    /* Send the Break character bit */
    SENDB = 0;
    /* Low or High baud rate selection bit */
    /* High Baud Rate */
    BRGH = 1;

    /* RCSTA :- Recepition Status and control Register */
    /* TX/RC7 and RX/RC6 act as serial port */
    SPEN = 1;
    /* 9bit RX enable or disable bit */
    RX9 = 0;
    /* Continous reception enable or disable */
    CREN = 1;

    /* BAUDCTL:- Baud rate control register */
    /* Auto baud detection overflow bit */
    ABDOVF = 0;
    /* 16bit baud generate bit */
    BRG16 = 0;
    /* Wakeup enable bit */
    WUE = 0;
    /* Auto baud detect enable bit */
    ABDEN = 0;

    /* Baud Rate Setting Register */
    /* Set to 10 for 115200, 64 for 19200 and 129 for 9600 */
    SPBRG = 129;


    /* TX interrupt enable bit */
    TXIE = 1;
    /* TX interrupt flag bit */
    TXIF = 0;
    /* RX interrupt enable bit */
    RCIE = 1;
    /* RX interrupt enable bit */
    RCIF = 0;
}
/* putch() and puts() definition
 * Description : receives the character to be transmitted and 
   it gets loaded in TSR from TXREG register when TSR is empty  
   and TSR transmits to teraterm byte by byte 
 */
void putch(unsigned char byte) {
    /* Output one byte */
    /* Set when register is empty */
    while (!TXIF) {
        continue;
    }
    TXREG = byte;
}

int puts(const char *s) {
    while (*s) {
        putch(*s++);
    }
    return 0;
}
/* getch() definition
 * Description : receives the data transmitted by teraterm 
   and stores it in RCREG register 
 * Return value : RCREG register value
 */
unsigned char getch(void) {
    /* Retrieve one byte */
    /* Set when register is not empty */
    while (!RCIF) {
        continue;
    }
    return RCREG;
}

unsigned char getche(void) {
    unsigned char c;

    c = getch;
    //putch(c = getch());

    return (c);
}

static void init_config(void) {
    //Write your initialization code here
    init_clcd();
    init_adc();
    init_matrix_keypad();
    init_i2c();
    init_ds1307();
    init_uart();   
}

/* main() definition 
 * Description:reads the key pressed and calls respective functions based on 
   SCREEN_FLAG and MENU_FLAG macros  
 */
void main(void) {
    init_config(); //Calling initializing function
    int long_press_sw5_delay = 0;
    while (1) {
        get_time();

        //read the key
        key = read_switches(LEVEL_CHANGE);

        //if MKP5 is pressed it should enter to password screen
        if (SCREEN_FLAG != MENU_SCREEN) {
            if (key == MK_SW11)
                long_press_sw5_delay++;
            if (long_press_sw5_delay > 300) {
                SCREEN_FLAG = PASSWORD_SCREEN;
                long_press_sw5_delay = 0;
            }
        }

        //if screen flag is dashboard the display dashboard screen
        if (SCREEN_FLAG == DASH_BOARD)
            display_dashboard();
        else if (SCREEN_FLAG == PASSWORD_SCREEN)//if screen flag is password the display password screen
            password_screen();
        //if screen flag is menu screen then display menu screen
        //it displays menu screen only on successfully entering of password
        else if (SCREEN_FLAG == MENU_SCREEN) {
            if (MENU_FLAG == VIEW_LOG) {
                view_log();
            } else if (MENU_FLAG == DOWNLOAD_LOG)
                download_log();
            else if (MENU_FLAG == CLEAR_LOG)
                clear_log();
            else if (MENU_FLAG == SET_TIME){
                set_time();
            }
            else if (MENU_FLAG == CHANGE_PASSWORD) {
                change_password();
            } else
                display_menu();
        }
    }

}
